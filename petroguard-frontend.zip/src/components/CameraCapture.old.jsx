import { useRef, useState, useEffect } from "react";

function CameraCapture({ onCapture }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const [stream, setStream] = useState(null);
  const [error, setError] = useState("");
const [cameraOpen, setCameraOpen] = useState(false);
  useEffect(() => {
 if (!cameraOpen) return;   async function startCamera() {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "environment",
          },
          audio: false,
        });

        setStream(mediaStream);

        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (err) {
        console.error(err);
        setError("Unable to access camera.");
      }
    }

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [cameraOpen]);
  function capturePhoto() {
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (!video || !canvas) return;

    const context = canvas.getContext("2d");

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    const imageData = canvas.toDataURL("image/jpeg", 0.9);

    if (onCapture) {
      onCapture(imageData);
    }
  }
  return (
    <div>
      <h3>📷 Camera Capture</h3>

      {error && <p>{error}</p>}
{!cameraOpen && (
  <button
    onClick={() => setCameraOpen(true)}
    style={{
      padding: "10px 16px",
      borderRadius: "8px",
      marginBottom: "12px",
    }}
  >
    📷 Capture Evidence
  </button>
)}
     {cameraOpen && (
  <video
    ref={videoRef}
    autoPlay
    playsInline
    style={{
      width: "100%",
      maxWidth: "400px",
      borderRadius: "8px",
    }}
  />
)}

      <br />
      <br /> 

      <button onClick={capturePhoto}>
        📷 Capture Photo
      </button>

      <canvas
        ref={canvasRef}
        style={{ display: "none" }}
      />
    </div>
  );
}

export default CameraCapture;
